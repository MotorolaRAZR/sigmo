return {
  "stevearc/overseer.nvim",
  opts = {},
}
