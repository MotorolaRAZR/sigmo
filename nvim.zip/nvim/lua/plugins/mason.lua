return {
  { "williamboman/mason.nvim" },
  { "neovim/nvim-lspconfig" },
}
